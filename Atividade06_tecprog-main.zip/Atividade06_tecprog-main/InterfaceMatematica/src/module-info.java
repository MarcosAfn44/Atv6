/**
 * 
 */
/**
 * 
 */
module InterfaceMatematica {
}