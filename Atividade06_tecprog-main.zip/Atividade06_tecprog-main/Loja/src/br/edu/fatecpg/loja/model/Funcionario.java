package br.edu.fatecpg.loja.model;

public interface Funcionario {
	
	//Método Obrigatório Para Todos Os Funcionários
	public void baterPonto();
	
}
